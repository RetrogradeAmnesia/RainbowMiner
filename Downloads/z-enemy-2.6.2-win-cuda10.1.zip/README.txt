Z-ENEMY 2.6.2  From: Dk & Enemy (z-enemy)

IMPORTANT:
For maximum performance make sure you have latest drivers 
http://www.nvidia.com/Download/index.aspx

Changes:
- Fixed compatibility with Nicehash, Miningpoolhub and some other pools ("epoch initialization failed" error).
- Fixed crash while trying to load json config files in Ubuntu 16 based distributions (HiveOS 4)
- Temporarily disabled environment variables in json config files in Ubuntu 16 based distributions (HiveOS 4)

_____________________________________
First time or troubleshooting kawpow:
-   First time users - all ver. 2.02+ works on Cuda 9.x &Cuda 10.x and it is recommended to make sure you've updated your NVIDIA drivers. You can find drivers here: http://www.nvidia.com/Download/index.aspx ver., min  ver.398+++
-   Next important thing is intensity. We recommend intensity for start -19 or 20,(21 for 20x0) at first.
-   kawpow algo using +mem , but use no OC at first until you verify stability.. 
